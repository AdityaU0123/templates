"use client"

import  from "../templates/includes/login/login"

export default function SyntheticV0PageForDeployment() {
  return < />
}