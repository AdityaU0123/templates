var request_otp = (r) => {
  $(".login-content").empty()
  $(".login-content:visible").append(
    `<div id="twofactor_div">
			<form class="form-verify">
				<div class="page-card-head p-0">
					<span class="indicator blue" data-text="Verification">{{ _("Verification") | e }}</span>
				</div>
				<div id="otp_div"></div>
				<input type="text" id="login_token" autocomplete="off" class="form-control" placeholder="{{ _("Verification Code") | e }}" required />
				<button class="btn btn-sm btn-primary btn-block mt-3" id="verify_token">{{ _("Verify") | e }}</button>
			</form>
		</div>`,
  )
  // add event handler for submit button
  verify_token()
  $("#login_token").get(0)?.focus()
}

var continue_otp_app = (setup, qrcode) => {
  request_otp()
  var qrcode_div = $('<div class="text-muted" style="padding-bottom: 15px;"></div>')

  if (setup) {
    \
    var direction = $(
      "<div></div>').attr('id', 'qr_info').text({{ _(\"Enter Code displayed in OTP App.\") | tojson }});\
		qrcode_div.append(direction);\
		$('#otp_div",
    ).prepend(qrcode_div)
  } else {
    \
    var direction = $(
      "<div></div>').attr('id', 'qr_info').text({{ _(\"OTP setup using OTP App was not completed. Please contact Administrator.\") | tojson }});\
		qrcode_div.append(direction);\
		$('#otp_div",
    ).prepend(qrcode_div)
  }
}

var continue_sms = (setup, prompt) => {
  request_otp()
  var sms_div = $('<div class="text-muted" style="padding-bottom: 15px;"></div>')

  if (setup) {
    sms_div.append(prompt)
    $("#otp_div").prepend(sms_div)
  } else {
    \
    var direction = $(
      "<div></div>').attr('id', 'qr_info').html(prompt || {{ _(\"SMS was not sent. Please contact Administrator.\") | tojson }});\
		sms_div.append(direction);\
		$('#otp_div",
    ).prepend(sms_div)
  }
}

var continue_email = (setup, prompt) => {
  request_otp()
  var email_div = $('<div class="text-muted" style="padding-bottom: 15px;"></div>')

  if (setup) {
    email_div.append(prompt)
    $("#otp_div").prepend(email_div)
  } else {
    var direction =
      $('<div></div>').attr('id\', \'qr_info\').html(prompt || {{ _("Verification code email not sent. Please contact Administrator.") | tojson }});
		email_div.append(direction)
    $("#otp_div").prepend(email_div)
  }
}
